/* 

  Builds ereg site from html files in the src/html directory.
  
   Files and source stored in separate folders, but compile out to a single HTML folder in public.
   This makes it easier to find the html you need, and not have to sift through a lot of extraneous directories or files...
   since the HTML has no nested dependencies other than images, styles, fonts and js. 
   State specific information, includes and repeated data etc. is stored in JSON.

  Tasks: Clean directories, Build HTML pages, Compile SASS,  Watch for changes,


*/


"use strict";
module.exports = function(grunt) { 
	grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'), 
    //Get rid of all files 
     clean: { 
        contents: ['public/html/*'], 
        all_css: ['public/css/*']
        },
    //Build html from partials and includes 
      mustache_render: {
        
        options: {
          files: [{"expand":true,"dir":"src/html/**/*.inc","ext":"inc"}],
           
         directory:"/src/html/**", 
         extension:".inc", 
         prefix:"", 
         prefix_dir:"", 
         prefix_file:"", 
         glob:""  
         
          
         
        },
      your_target: {
        options: { }, 
        files : [
              {
            expand: true,
            src: "src/html/**/*.html",
            data: "src/json/data.json", 
            flatten: true, 
            dest: "public/html/",
            rename: function (dest, src) {          
            // The `dest` and `src` values can be passed into the function
            return dest  + src.replace('src/html',''); 
            // The `src` is being renamed; the `dest` remains the same
          }
 
        }
      ] 
      } 
      },
      //Syntactically awesome stylesheets
      sass: {
       dist: {
          files: [{
            expand: true,
            cwd: 'src/scss',
            src: ['vendor/*.scss','*.scss'],
            dest: 'public/css/',
            ext: '.css'
          }]
        }
      },
      // Because who wants to run grunt every time you change something
      watch: {
        scripts: {
          files: ['src/**/*.scss','src/**/*.html','src/**/*.inc','src/**/*.json'],
          tasks: ['clean','mustache_render','sass'],
          options: {
            spawn: true,
          },
        },
      }

});
  grunt.loadNpmTasks('grunt-newer');
  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-mustache-render');  
  grunt.loadNpmTasks('grunt-contrib-sass');
	grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.registerTask('default', ['watch', 'clean','mustache_render','sass']);
 
 
};

  
 