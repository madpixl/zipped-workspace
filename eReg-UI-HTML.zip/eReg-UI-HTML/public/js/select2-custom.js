$(document).ready(function() {
    /**
     * Default select2 behavior
     * Enable select2 wherever .select2 occurs
     * No search bar
     * @type {String} Options
     */
    $(".select2").select2({
        placeholder: "Select",
        minimumResultsForSearch: -1,
    });

    /**
     * formats the drop down to show an X
     * @param  {JSONObject} option The actual JSON
     * @return {String}     HTML string containing formatting
     */
    function format(option) {
        if (!option.id) {
            return option.text; // optgroup
        }
        return option.text+'<i aria-hidden="true" class="icon-trash show-on-rollover pull-right"></i>';
    }

    /**
     * Options for the modal dialog
     * Pulled out so that they can be easily modified
     * @type {Object} Options for the modal
     */
    var modalOptions = {
        'show': true,
        'target': '#modal-container' // this will need to be revised
    };

    /**
     * necessary to attach custom select2 to the .select2-removable
     */
    var select2 = $(".select2-removable").select2({
        placeholder: "Select",
        formatResult: format,
        formatSelection: format,
        escapeMarkup: function(m) { return m; }
    }).data('select2');

    /**
     * Overridden onSelect function for removable select2s
     * @param  {Function} fn Add check to see if the X is selected
     *                       if it is, close the drop down and trigger the modal
     * @return {Function}    Apply the changes to the Select2 dropdown
     */
    if (select2) { // check to see if there is a removable select2 first
        select2.onSelect = ((function(fn) {
            return function(data, options) {
                var target;
                
                if (options !== null) {
                    target = $(options.target);
                }
                
                if (target && target.hasClass('show-on-rollover')) {
                    // must close in order to prevent z-indexing issues with modal
                    this.close();
                    // Not sure how to allow for multiple modals in the same window... at this point.
                    // will probably need to use AngularJS
                    $('#modal-container').modal(modalOptions);
                } else {
                    return fn.apply(this, arguments);
                }
            };
        })(select2.onSelect));
    }
});