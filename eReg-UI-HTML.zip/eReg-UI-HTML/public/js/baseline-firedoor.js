(function ($) {
  'use strict';


 /* FIREDOOR PUBLIC CLASS DEFINITION
  * =============================== */

  var Modal = $.fn.modal.Constructor;
  var Firedoor = function(element, options){
    this.init(element, options);
  };

  /* NOTE: FIREDOOR EXTENDS BOOTSTRAP-MODAL.js
     ========================================== */

  Firedoor.prototype = $.extend({}, Modal.prototype, {

    constructor: Firedoor,

    init: function (element, options) {

      // FIXME: Init only exists to be called because of
      // this pull request: https://github.com/twbs/bootstrap/pull/12835
      Modal.prototype.init.call(this, element, options);
      this.$element.delegate('[data-dismiss="firedoor"]', 'click.dismiss.firedoor', $.proxy(this.hide, this));

      this.$preserve = $(options.preserve);
      this.$position = options.position ? $(options.position) : this.$preserve;

      // Provide a loading spinner.
      if ($.fn.spin) {
        var spinner = new Spinner($.fn.spin.presets.tiny).spin();
        this.$element.find('.firedoor-loading-display').prepend(spinner.el);
      }

      var firedoor = this;
      this.$element
        .appendTo('body')
        .on('show.bs.modal', $.proxy(this.preserve, this))
        .on('shown.bs.modal', function(){
          firedoor.activate();
          firedoor.$element.addClass('firedoor-shown');
        })
        .on('hide.bs.modal', function(){
          firedoor.preserve();
          firedoor.activate(false);
          firedoor.$element.removeClass('firedoor-shown');
        });

      this.load();
    },

    activate: function(activate) {
      activate = activate !== false;
      if (this.$activator) {
        this.$activator.removeClass('firedoor-activated');
      }
      if (activate && this.options.source) {
        this.$activator = this.options.source.closest(this.options.activator);
        this.$activator.addClass('firedoor-activated');
      }
    },

    preserve: function() {
      if (this.$preserve.length === 0) {
        return;
      }

      // TODO: This position should react to browser resizing.
      var left = this.isShown ? 0 : -this.$preserve.offset().left + this.options.margin;

      this.$position
        .toggleClass('firedoor-shown', !this.isShown)
        .css({position: 'relative', left: left});
    }

  });


 /* FIREDOOR PLUGIN DEFINITION
  * ========================== */

  var old = $.fn.firedoor;

  $.fn.firedoor = function (option) {
    return this.each(function () {
      var $this = $(this),
          options = $.extend({}, $.fn.firedoor.defaults, $this.data(), typeof option === 'object' && option),
          data = $this.data('firedoor');

      if (!data) {
        $this.data('firedoor', (data = new Firedoor(this, options)));
      }

      var load = data.options.remote !== options.remote;
      if (!load && data.isShown) {
        option = 'toggle';
      }
      options.show = !data.isShown;

      // This may be overkill, but it's used to store the current state on the Firedoor.
      $.extend(data.options, options);

      if (load) {
        data.load();
      }

      if (typeof option === 'string') {
        data[option]();
      } else if (options.show) {
        data.show();
      }
    });
  };

  $.fn.firedoor.Constructor = Firedoor;

  $.fn.firedoor.defaults = $.extend({} , $.fn.modal.defaults, {
    backdrop: false,
    preserve: null, // Keep this item in view.
    position: null,  // Position with this (parent) element.
    activator: 'tr',
    source: null, // The element that triggers the firedoor.
    margin: 30,
    classes: {
      loading: 'firedoor-loading',
      body: 'firedoor-body',
      header: 'firedoor-header'
    }
  });


 /* FIREDOOR NO CONFLICT
  * ==================== */

  $.fn.firedoor.noConflict = function () {
    $.fn.firedoor = old;
    return this;
  };


 /* FIREDOOR DATA-API
  * ================= */

  $(document).on('click.firedoor.data-api', '[data-toggle="firedoor"]', function (e) {

    var $this = $(this),
        href = $this.attr('href'),
        $target = $($this.attr('data-target') || (href && href.replace(/.*(?=#[^\s]+$)/, ''))), //strip for ie7
        baseOptions = { remote:!/#/.test(href) && href, source: $this },
        option = $.extend(baseOptions, $target.data(), $this.data());

    e.preventDefault();

    $target
      .firedoor(option)
      .one('hide', function () {
        $this.focus();
      });
  });

}(window.jQuery));
