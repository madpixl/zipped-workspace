(function($, undefined) {
  'use strict';

  var DateSelectPresets = function (options) { this.init(options); },
      defaults;

  defaults = {

    // startDate and endDate are both in the past
    previous: {
      _base: function (d, unit, count) {
        var date = moment(d).subtract(unit, count).startOf(unit);
        return [moment(date), date.add(unit, count-1).endOf(unit)];
      },

      day: function (d, count, presets) {
        return presets.previous._base(d, 'day', count);
      },
      week: function (d, count, presets) {
        return presets.previous._base(d, 'week', count);
      },
      month: function (d, count, presets) {
        return presets.previous._base(d, 'month', count);
      },
      quarter: function (d, count) {
        var unit = 'month',
            month = d.month(Math.floor(d.month()/3)*3).subtract(unit, count*3).startOf(unit);
        return [moment(month), month.add(unit, (count-1) * 3 + 2).endOf(unit)];
      },
      year: function (d, count, presets) {
        return presets.previous._base(d, 'year', count);
      }
    },

    // startDate and is in the past, endDate is today, length is fixed
    last: {
      _base: function (d, unit, count) {
        var date = moment(d).subtract(unit, count);
        return [moment(date).add(1, 'day'), date.add(unit, count)];
      },

      week: function (d, count, presets) {
        return presets.last._base(d, 'week', count);
      },
      month: function (d, count, presets) {
        return presets.last._base(d, 'month', count);
      },
      year: function (d, count, presets) {
        return presets.last._base(d, 'year', count);
      }
    },

    // startDate is in the past, endDate is in the future, count is always 1
    current: {
      _base: function (d, unit) {
        var date = moment(d).startOf(unit);
        return [moment(date), date.endOf(unit)];
      },

      day: function (d, count, presets) {
        return presets.current._base(d, 'day', count);
      },
      week: function (d, count, presets) {
        return presets.current._base(d, 'week', count);
      },
      month: function (d, count, presets) {
        return presets.current._base(d, 'month', count);
      },
      quarter: function (d) {
        var unit = 'month',
            month = d.month(Math.floor(d.month()/3)*3).startOf(unit);
        return [moment(month), month.add(unit, 2).endOf(unit)];
      },
      year: function (d, count, presets) {
        return presets.current._base(d, 'year', count);
      }
    },

    // startDate is in the past, endDate is today, startDate is fixed
    todate: {
      _base: function (d, unit) {
        var date = moment(d).startOf(unit);
        return [date, d];
      },

      month: function (d, count, presets) {
        return presets.todate._base(d, 'month', count);
      },
      quarter: function (d) {
        var unit = 'month',
            month = moment(d).month(Math.floor(d.month()/3)*3).startOf(unit);
        return [month, d];
      },
      year: function (d, count, presets) {
        return presets.todate._base(d, 'year', count);
      }
    },

    // startDate is today, endDate is in the future, startDate is fixed
    fromdate: {
      _base: function (d, unit) {
        var date = moment(d).endOf(unit);
        return [d, date];
      },

      month: function (d, count, presets) {
        return presets.fromdate._base(d, 'month', count);
      },
      quarter: function (d) {
        var unit = 'month',
            month = moment(d).month(Math.floor(d.month()/3)*3).add(2, unit).endOf(unit);
        return [moment(d), month];
      },
      year: function (d, count, presets) {
        return presets.fromdate._base(d, 'year', count);
      }
    },

    // startDate is today, endDate is in the future, length is fixed
    next: {
      _base: function (d, unit, count) {
        var date = moment(d);
        return [d, date.add(unit, count).subtract(1, 'day')];
      },

      day: function (d, count, presets) {
        return presets.next._base(d, 'day', count);
      },
      week: function (d, count, presets) {
        return presets.next._base(d, 'week', count);
      },
      month: function (d, count, presets) {
        return presets.next._base(d, 'month', count);
      },
      year: function (d, count, presets) {
        return presets.next._base(d, 'year', count);
      }
    },

    // startDate and endDate are both in the future
    following: {
      _base: function (d, unit, count) {
        var date = moment(d).add(unit, count).endOf(unit);
        return [moment(date).subtract(unit, count-1).startOf(unit), date];
      },

      day: function (d, count, presets) {
        return presets.following._base(d, 'day', count);
      },
      week: function (d, count, presets) {
        return presets.following._base(d, 'week', count);
      },
      month: function (d, count, presets) {
        return presets.following._base(d, 'month', count);
      },
      quarter: function (d, count) {
        var unit = 'month',
            month = moment(d).month(Math.floor(d.month()/3)*3).add(3, unit).startOf(unit);
        return [moment(month), month.add(count * 3 - 1, unit).endOf(unit)];
      },
      year: function (d, count, presets) {
        return presets.following._base(d, 'year', count);
      }
    }

  };

  $.extend(DateSelectPresets.prototype, {

    init: function (options) {
      this.options = $.extend({}, options);
      this.options.baseDate = moment(this.options.baseDate);
      this.presets = $.extend({}, defaults, options.custom);
    },

    invoke: function (preset) {
      var method = this.presets,
          args = preset.split(':'),
          names = args[0].split('.'),
          count = parseInt(args[1], 10) || 1;
      for (var i=0, child; i<names.length; i++) {
        child = method[names[i]];
        if (child) {
          method = child;
        } else {
          return false;
        }
      }
      return this.toDates(method.call(this.presets, moment.utc(this.options.baseDate), count, this.presets));
    },

    toDates: function (dates) {
      return $.map(dates, function(date){ return date.startOf('day').toDate(); });
    }

  });

  $.fn.dateselect.presets = {
    Constructor: DateSelectPresets,
    defaults: defaults
  };

}(jQuery));