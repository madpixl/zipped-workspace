(function ($) {
  'use strict';

  var Modal = $.fn.modal.Constructor;

  /* NOTE: MODAL EXTENDS BOOTSTRAP-MODAL.js
     ========================================== */

  $.extend(Modal.prototype, {

    activate: $.noop,

    // FIXME: Init only exists to be overridden because of
    // this pull request: https://github.com/twbs/bootstrap/pull/12835
    init: function(element, options) {
      this.options   = options;
      this.$element  = $(element);
      this.$backdrop = null;
      this.isShown   = null;
      this.load();
    },

    load: function() {
      this.activate();
      if (this.options.remote) {
        var _this = this;
        var classes = this.options.classes;
        this.$element.addClass(classes.loading).find('.'+classes.body).load(this.options.remote, function(){
          var $title = _this.options.remoteTitle && $(this).find(_this.options.remoteTitle),
              $heading = _this.$element.find('.' + classes.header + ' h3');

          if ($title && $title.length) {
            $heading.html($title.remove().html());
          }

          _this.$element.removeClass(classes.loading);
        });
      }
    }

  });

 /* MODAL PLUGIN DEFINITION
  * ======================= */

  $.extend(Modal.DEFAULTS, {
    remoteTitle: null,
    classes: {
      loading: 'modal-loading',
      body: 'modal-body',
      header: 'modal-header'
    }
  });

}(window.jQuery));