(function($, undefined) {
  'use strict';

  var dependencyCheck = function () {
    var pass = window.moment && moment.version[0] === '2';
    if (!pass) {
      console.log('Moment.js version 2.x is required for Baseline dateselect');
    }
    return pass;
  };

 /* DATESELECT PUBLIC CLASS DEFINITION
  * ================================= */

  var DateSelect = function (element, options) {
    this.init(element, options);
  };

  DateSelect.prototype = {

    open: false,
    focused: false,
    endpoints: ['from', 'to'],

    init: function(element, options) {
      var $element = $(element),
          $inputs = options.inputs || $element.find('input'),
          isRange = $inputs.length > 1,
          templateKey = isRange ? 'range' : 'single',
          $display = $(options.template[templateKey].display).appendTo($element),
          $targets = $(options.template[templateKey].inline),
          $mockInput = $display.find('.dateselect__display'),
          $focus = $element.find('.dateselect__focus'),
          DateSelectPresets = $.fn.dateselect.presets && $.fn.dateselect.presets.Constructor;

      $.extend(this, {
        $element: $element,
        $inputs: $inputs,
        $display: $display,
        $targets: $targets,
        $mockInput: $mockInput,
        $focus: $focus,
        options: options,
        methods: {
          get: $.proxy(this.getDate, this),
          set: $.proxy(this.setDate, this),
          preset: $.proxy(this.setPreset, this)
        }
      });

      if (DateSelectPresets) {
        this.$presetsDisplay = options.presets.list || $element.find('.dateselect__presets');
        this.$presetsDisplay.addClass('nav nav-pills pull-left nav-stacked');
        this.presets = new DateSelectPresets(options.presets);
      }

      if (options.autoClose) {
        options.autoUpdate = true;
      }

      this.range = options.dates;
      if (!this.range) {
        // Set range from input dates, if present.
        this.range = $inputs.map(function(){
          return moment.utc($(this).val(), options.format.value).toDate();
        }).toArray();
      }
      if (!this.range) {
        // Set range to placeholder values.
        this.range = isRange ? [new Date(), new Date()] : [new Date()];
      }

      this.popover();

      // Pass through to $.fn.datepicker.
      $element.datepicker($.extend({ inputs: $targets.toArray() }, options, { format: options.format.date }));
      this.rangepicker = $element.data('datepicker');
      this.datepickers = this.rangepicker.pickers;
      // Bind our events after those bound by $.fn.datepicker()
      this.bindEvents();
      this.setDate(this.range);
      if (!options.autoUpdate) {
        this.update({});
      }
    },

    popover: function(){
      var $display = this.$display,
          $popoverContent;

      if (!this.$popover) {
        this.$popover = $display.find('.input-group-btn i')
          .click($.proxy(this.click, this))
          .popover({
            trigger: 'manual',
            content: ' ', // Without some content, a popover is not ititialized.
            placement: $.proxy(this.detectPlacement, this),
            container: 'body'
          });

        // Proxy the popover hide method to our hide method to manage state more consistently.
        // Beware, monkey-patching.
        this.popoverData = this.$popover.data('bs.popover');
        this.popoverData.hideOriginal = this.popoverData.hide;
        this.popoverData.hide = $.proxy(this.hide, this);

        $popoverContent = $(this.options.template.content);

        if(this.$presetsDisplay.length){
          $popoverContent.append(this.$presetsDisplay);
        }

        $popoverContent.append(this.$targets);

        if(!this.options.autoClose) {
          $popoverContent.append($(this.options.template.footer));
          this.$confirm = $popoverContent.find('.dateselect__confirm');
          this.$confirm.find('span').text(this.options.textConfirm);
          this.$cancel = $popoverContent.find('.dateselect__cancel');
          this.$cancel.find('span').text(this.options.textCancel);
        }

        // Some manual manipulation of popover contents, because popover's
        // setContent converts to HTML (and thus loses events).
        this.popoverData.tip().append($popoverContent).addClass('dateselect__popover');

      }

      return this.$popover;
    },

    bindEvents: function() {
      var _this = this;
      this.$display.on('click', $.proxy(this.click, this));
      this.$focus
        .on('focus', $.proxy(this.focus, this))
        .on('blur', $.proxy(this.closedBlur, this))
        .on('keydown', $.proxy(this.keydown, this));

      this.$targets.each(function(index){
        $(this).on('changeDate', function(e){
          _this.change(e, index);
        });
      });

      this.$presetsDisplay.find('a[data-preset]').on('click', function() {
        _this.setPreset($(this).data('preset'));
      });

      if(!this.options.autoClose) {
        this.$confirm.on('click', $.proxy(this.hide, this));

        this.$cancel.on('click', function(e) {
          _this.setDate(_this.rangeWhenOpened);
          _this.hide(e);
        });
      }

    },

    update: function(e) {
      e.dateRange = this.range;
      // The changeDate event is deprecated and will be removed by 1.0.0.
      this.$element.trigger('changeDate', e);
      this.$element.trigger('change.dateselect', e);
      this.updateBoundInputs();
      this.renderDisplay();
    },

    change: function(e, index) {
      this.range = this.$element.data('datepicker').dates;
      this.$presetsDisplay.find('a[data-preset]').parent().removeClass('active');
      if (this.options.autoUpdate) {
        this.update(e);
      }
      // If all range endpoints have been set and autoClose is true, hide.
      if (this.rangeSet(index)) {
        this.hide();
      }
    },

    click: function(e) {
      // TODO: Find a way to not stop propagation.
      e.stopPropagation();
      this[this.open ? 'hide' : 'show'](e);
    },

    keydown: function(e) {
      switch (e.keyCode) {
      case 9: // tab
        this.blur(e);
        break;
      }
    },

    focus: function(e) {
      if (!this.focused) {
        this.focused = true;
        this.$mockInput.addClass('focus');
        if (!this.closing) {
          this.show(e);
        }
      }
      this.closing = false;
    },

    blur: function(e, hide) {
      if (this.focused || !this.open) {
        this.$mockInput.removeClass('focus');
        if (hide !== false) {
          this.hide(e);
        }
        this.focused = false;
      }
    },
    
    // This is not pretty, but it's clearer than adding more logic to
    // blur.
    closedBlur: function(e) {
      if (!this.open) {
        this.blur(e, false);
      }
    },

    show: function() {
      if (!this.open) {
        this.open = true;
        this.rangeSet();
        this.rangeWhenOpened = this.range.slice(0);
        this.popover().popover('show');
        this.$focus.focus();
      }
    },

    hide: function(e) {
      if (this.open) {
        // Unless we're tabbing out, or a click has bubbled to the document, 
        // we want to re-focus the $focus input.
        if (!e || e.type !== 'keydown' && e.currentTarget !== document) {
          this.closing = true;
          this.$focus.focus();
        } else {
          this.blur(e, false);
        }
        if (!e || e.type !== 'hide') {
          this.popoverData.hideOriginal();
        }
        if (!this.options.autoUpdate) {
          this.update(e);
        }
        this.$element.trigger('hide.dateselect');
        this.open = false;
      }
    },

    detectPlacement: function(){
      var dim = {
        view: {
          width: $(window).width(),
          height: $(window).height(),
        },
        element: $.extend(this.$element.offset(), {
          width: this.$element.width(),
          height: this.$element.height(),
        }),
        scroll: {
          left: $(window).scrollLeft(),
          top: $(window).scrollTop()
        }
      }, space = {
        top: dim.element.top - dim.scroll.top,
        bottom: dim.view.height - (dim.element.top - dim.scroll.top + dim.element.height),
        left: dim.element.left - dim.scroll.left,
        right: dim.view.width - (dim.element.left - dim.scroll.left + dim.element.width)
      };

      // TODO: Detect placement in viewport and return appropriate value.
      //   top | bottom | left | right

      // TODO: Support popover corner placement.
      //   top.left | left.top | ...

      // Currently, we just return top|bottom or left|right wherever there's more space.
      if (this.options.gravity === 'vertical') {
        return space.top > space.bottom ? 'top' : 'bottom';
      } else {
        return space.left > space.right ? 'left' : 'right';
      }
    },

    rangeSet: function (index) {
      var close = true;
      if (this.options.autoClose) {
        if (index === undefined) {
          this.rangeSetSinceOpened = this.range.length > 1 ? [false, false] : [false];
        } else if(this.rangeSetSinceOpened) {
          this.rangeSetSinceOpened[index] = true;
          $.each(this.rangeSetSinceOpened, function(index, isSet) {
            close = close && isSet;
          });
          return close;
        }
      }
      return false;
    },

    updateBoundInputs: function() {
      for (var i=0; i<this.range.length; i++) {
        var formatted = moment.utc(this.range[i]).format(this.options.format.value);
        this.$inputs.eq(i).val(formatted);
      }
    },

    renderDisplay: function() {
      for (var i=0; i<this.range.length; i++) {
        var formatted = moment.utc(this.range[i]).format(this.options.format.date);
        this.$display.find('.dateselect__date--'+this.endpoints[i]).html(formatted);
      }
    },

    getDate: function () {
      // Single dates will be returned as a value instead of an array.
      return this.range.length > 1 ? this.range : this.range[0];
    },

    setDate: function (values) {
      if (!values) {
        return false;
      }

      // Single dates may be passed as a value instead of an array.
      values = $.isArray(values) ? values : [values];

      var options = this.options,
          dates = $.map(values, function(value){
            var date = value instanceof Date ? moment(value) : moment(value, options.format.value);
            return date.utc().toDate();
          });

      for (var i=0, datepicker, date; i<this.datepickers.length; i++) {
        datepicker = this.datepickers[i];
        date = dates[i];
        if (date) {
          datepicker._setDate(date);
        }
      }

      return this.getDate();
    },

    setPreset: function(presetString) {
      var range = this.presets && this.setDate(this.presets.invoke(presetString));
      if (range) {
        this.$presetsDisplay.find('a[data-preset="'+presetString+'"]').parent().addClass('active');
      }
      return range;
    }

  };

 /* DATESELECT PLUGIN DEFINITION
  * =========================== */

  var old = $.fn.dateselect;

  $.fn.dateselect = function (option) {
    if (!dependencyCheck()) { return this; }
    var args = Array.prototype.slice.call(arguments, 1),
        data;

    // Methods are called via strings, and can only be applied to one jQuery object.
    if (typeof option === 'string' && this.length === 1) {
      data = this.eq(0).data('dateselect');
      return data && data.methods[option].apply(data, args);
    }

    return this.each(function () {
      var $this = $(this),
          options = $.extend(true, {}, $.fn.dateselect.defaults, $this.data(), typeof option === 'object' && option);
      data = $this.data('dateselect');
      if (!data) {
        $this.data('dateselect', (data = new DateSelect(this, options)));
      }
    });
  };

  $.fn.dateselect.Constructor = DateSelect;

  $.fn.dateselect.defaults = {
    gravity: 'vertical',
    autoClose: true,
    autoUpdate: true,
    format: {
      date: 'MMMM Do YYYY',
      time: 'h:mm:ss a',
      value: 'X' // Unix timestamp.
    },
    template: {
      range: {
        display: '<input class="input-offscreen dateselect__focus" /><div class="input-group"><div class="dateselect__display form-control input-xlarge"><span class="dateselect__date--from"></span> - <span class="dateselect__date--to"></span></div><span class="input-group-btn"><span class="btn btn-input"><i class="icon-calendar icon-solo" aria-hidden="true"></i></span></span></div>',
        inline: '<div class="dateselect__datepicker--inline dateselect__datepicker--from" /><div class="dateselect__datepicker--inline dateselect__datepicker--to" />',
      },
      single: {
        display: '<input class="input-offscreen dateselect__focus" /><div class="input-group"><div class="dateselect__display form-control"><span class="dateselect__date--from"></span></div><span class="input-group-btn"><span class="btn btn-input"><i class="icon-calendar icon-solo" aria-hidden="true"></i></span></span></div>',
        inline: '<div class="dateselect__datepicker--inline dateselect__datepicker--from" />',
      },
      content: '<div class="dateselect__popover-content" />',
      footer: '<div class="dateselect__footer clearfix"><button class="btn btn-default pull-right dateselect__confirm" tabindex="-1"><i class="icon-check"></i><span></span></button><button class="btn btn-link pull-right btn-space dateselect__cancel" tabindex="-1"><span></span></button></div>'
    },
    presets: {
      custom: {}
    },
    todayHighlight: true,
    textConfirm: 'Select',
    textCancel: 'Cancel'
  };

  /* DATESELECT NO CONFLICT
  * ====================== */

  $.fn.dateselect.noConflict = function(){
    $.fn.dateselect = old;
    return this;
  };


}(window.jQuery));
