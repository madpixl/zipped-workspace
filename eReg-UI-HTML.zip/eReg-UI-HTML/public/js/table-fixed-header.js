 $(window).on('affix.bs.affix', function () {

  var affixClass = "affix";
  var contentIdentifier = ".main-content";
  var iAttrs = new Object();
  iAttrs.id = $('.no-bs-affix').attr('id');
  iAttrs.tableId = $('table .no-bs-affix').attr('id');
  if (iAttrs.id == iAttrs.tableId && $('.no-bs-affix').length > 1) {
    iAttrs.id = $('.no-bs-affix')[1].id;
    // console.log("two floats");
  }

  iAttrs.offset = $('#'+iAttrs.id).attr('data-offset-top');
  // console.log(iAttrs.id+", "+iAttrs.offset);
  // console.log(iAttrs.tableId+", "+iAttrs.offset);
  /**
   * Build an identifier string based on id
   * @param  {String} elementIdentifier The value of attribute id="..."
   * @return {String}                   The id in this format "#idvalue"
   */
   var getElementDesignator = function(elementIdentifier) {
    if (!elementIdentifier) {
      $log.log("Error parsing the id of the element. Please set id.");
      // fall back on default class identifier
      elementIdentifier = ".no-bs-affix";
    } else {
      elementIdentifier = "#"+elementIdentifier;
      // $log.log(elementIdentifier);
    }
    return elementIdentifier;
  };

  var floatElement = function() {
    var element = $(getElementDesignator(iAttrs.id));
      maxWidth = element.width();
      // default scrollOffset is the height of the header + 5px
      var scrollOffset = $("header").outerHeight() + 5;
      // can be manually set by passing in offset-top=#
      if (iAttrs.offsetTop) {
        scrollOffset = iAttrs.offsetTop;
      }

      var topMargin = 0;
      if (iAttrs.topElement && $("#"+iAttrs.topElement) && $("#"+iAttrs.topElement).outerHeight()) {
        topMargin = $("#"+iAttrs.topElement).outerHeight();
        // $log.log("height:"+topMargin);
      }

      var currentScroll = $(this).scrollTop();
      if (currentScroll > scrollOffset && floatActive()) {
        if (!setFixed(topMargin)) {
          element.addClass(affixClass);
          adjustTableHeaderWidth();
          element.width(maxWidth);
        }
      } else {
        element.removeClass(affixClass);
        element.removeAttr('style');
      }
  };

  /**
   * "Intelligently" set the width of the floating table header
   * Only applicable on pages that have tables.
   * @return {void}
   */
   var adjustTableHeaderWidth = function() {
    var elementId = getElementDesignator(iAttrs.id);
    var numRows = $(elementId + ' + tbody tr');
    if (numRows) {
      numRows = numRows.length;
    }
    // // $log.log("numrows:"+numRows);
    if (numRows && numRows > 0) {
      $td = $(elementId + ' + tbody tr:first-child td');

        // if the table is essentially empty, don't bother affixing
        if (numRows < 2) {
          $(elementId).removeClass(affixClass);
        }
        else {
          $th = $(elementId + ' tr:first-child th');

          $th.each(function (index) {
            $td.eq(index).width($(this).width());
          });

          $td.each(function (index) {
            $th.eq(index).width($(this).width());
            // $log.log("index:"+index+", th:"+$(this).width()+", td:"+$td.eq(index).width());
          });
        }
      }
    };

  /**
   * Do not float the element if it is larger than the page content
   * @return {boolean} If the float should be active or not
   */
   var floatActive = function() {
    var elementId = getElementDesignator(iAttrs.id);
    var floats = true;
    var contentHeight = $(contentIdentifier);
    if (contentHeight) {
      contentHeight = contentHeight.height();
      // $log.log("contentHeight:"+contentHeight);
    }
    if (contentHeight && contentHeight > 0 && ($(elementId).height() > contentHeight)) { // || $(elementId).height() > $(window).height())) {
      // $log.log("elementHeight:"+$(elementId).height());
      // $log.log("windowHeight:"+$(window).height());
      floats = false;
    }
    // $log.log(floats);

    return floats;
  };

  /**
   * set the class to fixed if it exceeds the footer
   * in order to hold its location but not scroll any further
   */
   var setFixed = function() {
    var elementId = getElementDesignator(iAttrs.id);
    if ($(elementId).offset()) {
      var sidebarLocation = $(elementId).offset().top + $(elementId).height();
      var footerLocation = $(".footer").offset().top;
      // check location+height vs location of footer (need to stop before hits footer)
      // $log.log("sidebarLocation:"+sidebarLocation+";footerLocation:"+footerLocation);
      // $log.log("scrollposition: "+$(this).scrollTop());
      if ($(this).scrollTop()+$(elementId).height() > (footerLocation-50)) {
        // $log.log("too far, sidebarLocation:"+sidebarLocation+"; footerLocation"+footerLocation);
        // set its position to be above the footer
        $(elementId).offset({top: ($(elementId).offset().top - (sidebarLocation - footerLocation) - 50), left: $(elementId).offset().left});
        // $log.log("overlap:"+(sidebarLocation - footerLocation));
        // $log.log("top:"+$(elementId).offset().top);
        return true;
      }
      else {
        $(elementId).css('top',0);
        return false;
      }
    }
  };

  floatElement();
});
