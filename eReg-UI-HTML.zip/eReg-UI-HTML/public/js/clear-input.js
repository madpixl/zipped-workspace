$(document).ready(function() {
    // hides and shows the x on there being values
    $('#search-deals.clearable').keyup(function() {
        $('#search-deals + .clearicon').toggle(Boolean($(this).val()));
    });
    $('#search-deals + .clearicon').toggle(Boolean($("#search-deals.clearable").val()));

    // clears the input field
    $('#search-deals + .clearicon').click(function() {
        $('#search-deals.clearable').val('').focus();
        $(this).hide();
    });
});