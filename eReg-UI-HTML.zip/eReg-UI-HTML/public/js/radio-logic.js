// To use, make the radio button Value the id of the Section that you want to show or hide.
// Use the ID for container of that Section as the radio button group name.

$(function() {
            //apply click function to all radios
            $(".radio-inline input[type='radio']").click(function() {
                //when the click happens get the value which is the target class name... 
                var targetId = $(this).val();

                //Container for sections          
                var targetContext = $(this).attr("name");
                
                //id to show or hide 
                var divId 
                $('input[name="'+targetContext+'"]').each(function () { 
                divId = $(this).val();  

                    if (divId == targetId) {
                        $("#" + divId).addClass("show-it");
                        $("#" + divId).removeClass("hide-it");
                    } else { 
                        $("#" + divId).addClass("hide-it");
                        $("#" + divId).removeClass("show-it");
                    }
                });              
            })
        });