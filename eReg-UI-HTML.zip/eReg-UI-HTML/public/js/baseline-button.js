(function ($) {
  'use strict';

  var Button = $.fn.button.Constructor;
  var original = $.extend({}, Button.prototype);

  Button.prototype.setState = function (state) {
    var d = 'disabled';
    var $element = this.$element;

    if (state==='spin') {
      if (this.state !== 'spin') {
        // Push to event loop to allow forms to submit
        setTimeout(function () {
          $element.prepend('<span class="loading-spinner"><i class="icon-spinner animation-icon-spin"></i> </span>');
        }, 0);
      }
    } else {
      $element.children('.loading-spinner').remove();
      original.setState.call(this, state);
    }

    this.state = state;
  };

 /* BUTTON DATA-API
  * =============== */

  $(document).on('click.button.data-api', '[data-toggle^=spinner]', function (e) {
    var $btn = $(e.target);
    if (!$btn.hasClass('btn')) {
      $btn = $btn.closest('.btn');
    }
    $btn.button('spin');
  });

}(window.jQuery));