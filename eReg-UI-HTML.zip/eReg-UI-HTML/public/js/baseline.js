/*!
 * Baseline
 *
 * Copyright 2013 Dealer Dot Com, Inc.
 */

(function ($) {
  'use strict';

  $.baseline = {
    'version': '0.5.2',
  };

}(window.jQuery));