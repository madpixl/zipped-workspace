$(function(){
    $('a, button').click(function() {
        $('.btn[data-toggle="spinner"]').button('spin');
		$(this).toggleClass('active');
    });
});