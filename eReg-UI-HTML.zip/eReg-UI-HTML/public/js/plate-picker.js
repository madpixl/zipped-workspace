// Javascript for prototype of PA plate picker 
 
//show series by selected. 
$(function() { 
	$('#series-selection.select2').on('change', function() {
	 
	var series = "#series-" + this.value;
	//reset the list 
	$(".plate-grid .plate-list").removeClass("show-it");  
	$(".plate-grid .plate-list").addClass("hide-it");
	//hit the class  
	$(series).removeClass("hide-it"); 
	$(series).addClass("show-it"); 
	 
	}); 

	
	//Turn license plates green 
 
    $('.plate-list li').on('click', function() {
		
		if(!$(this).hasClass('inact')) {
			if ($(this).hasClass('success')) {
                $(this).removeClass('success');
                 $('#chosen-plate').addClass('hide-it');
                } else {
                $('.plate-list li').removeClass('success');
                $(this).addClass('success');
                 var selected_plate = $(this).text();
                $('#chosen-plate').removeClass('hide-it');
                //$('#chosen-plate li').addClass('success');
                $('#plate-num').text(selected_plate);
                //use the confirm button to select plate and close dialog. 
                   $('html, body').animate({
                     scrollTop: $('#get-inventory-fees').offset().top
                   });
                $('#wiz1-finalize').click(); 
			}
		} 
	});
	 
	//dynamic columns control
   	$('#showhide').on('click', function() { 
	 
	 if ($(this).text() === 'Hide') {
	 $(this).text("Show");
	 $('.inact').removeClass("show-it"); 
	 $('.inact').addClass("hide-it"); 
	 } else {
	 $(this).text("Hide");
	 $('.inact').addClass("show-it");
	 $('.inact').removeClass("hide-it");   	 
	 }
	}); 
	
});
 // Find a plate
    function filter(element) {
        var value = $(element).val().toUpperCase();

        $(".plate-grid > ul > li").each(function() {
            if ($(this).text().search(value) > -1) {
                $(this).show();
            }
            else {
                $(this).hide();
            }
        });
    }
    
 