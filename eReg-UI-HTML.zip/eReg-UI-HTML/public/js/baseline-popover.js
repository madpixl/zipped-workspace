(function ($) {
  'use strict';

  var Popover = $.fn.popover.Constructor;
  var original = $.extend({}, Popover.prototype);
  var clickEvents = 'click.bs.popover.data-api touchend.bs.popover.data-api';
  var autocloseClass = 'popover-autoclose';

  Popover.prototype.load = function () {
    var $popover = this.tip(),
        href = this.$element.attr('href'),
        _this = this;

    if (!this._remoteContent && !this.loading && href) {
      this.loading = true;

      $.get(href, {}, function(data){
        var $content = $('<div />').html(data),
            title = _this.options.remoteTitle && $content.find(_this.options.remoteTitle).remove().html();

        _this.loading = false;

        _this._remoteTitle = title;
        _this._remoteContent = $content.html() || data;

        if (data) {
          // Popovers manually hide empty titles, we need to bring them back.
          if (title) {
            $popover.find('.popover-title').show();
          }
          // Set content to trigger dom update.
          _this.setContent();
          _this.show();
          $popover.trigger('content-loaded.bs.popover');
        }
      }, 'html');

    }

    return 'Loading...';
  };

  Popover.prototype.getTitle = function () {
    return this._remoteTitle || original.getTitle.call(this);
  };

  Popover.prototype.getContent = function () {
    return this._remoteContent || original.getContent.call(this) || this.load();
  };

  // Prevent clicks from navigating to popover content.
  Popover.prototype.toggle = function (e) {
    if (e) { e.preventDefault(); }
    original.toggle.call(this, e);
  };

  // FIXME: This method requires a string first argument unless
  // this pull request is accepted unchanged: https://github.com/twbs/bootstrap/pull/12835
  Popover.prototype.init = function (element, options) {
    original.init.call(this, element, options);

    var _this = this;
    var $popover = this.tip();
    var $element = this.$element;

    if (this.options.autoClose) {
      $element.on(clickEvents, function(e) {
        e.stopPropagation();
      })
      .on('show.bs.popover hide.bs.popover', function(e){
        _this.shown = e.type === 'show';
        $element.toggleClass(autocloseClass, _this.shown);
      });

      $popover.on(clickEvents, function(e) {
        e.stopPropagation();
      });
    }

  };

  $.extend(Popover.DEFAULTS, {
    html: true,
    remoteTitle: null,
    autoClose: true
  });

  $(document).on(clickEvents, function (e) {
    $('.'+autocloseClass).each(function(){
      var popover = $(this).data('bs.popover');
      if (popover.shown) {
        popover.hide(e);
      }
    });
  });

}(window.jQuery));
